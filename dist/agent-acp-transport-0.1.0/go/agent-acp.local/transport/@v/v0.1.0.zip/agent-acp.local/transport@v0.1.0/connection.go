// Adapted from github.com/coder/acp-go-sdk v0.20.0 (Apache-2.0).
// Changes add selected-frame receipts, strict routing and payload-free diagnostics.

package transport

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	notificationQueueDrainTimeout = 5 * time.Second
	defaultMaxQueuedNotifications = 1024
)

var errNotificationQueueOverflow = errors.New("notification queue overflow")

type anyMessage struct {
	inbound *selectedReceipt
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Method  string          `json:"method,omitempty"`
	Params  json.RawMessage `json:"params,omitempty"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *RequestError   `json:"error,omitempty"`
}

type queuedNotification struct {
	seq     uint64
	arrival uint64
	msg     *anyMessage
}

// handlingNotification is the ctx value that processNotifications gives each
// notification handler. arrival is the notification's place among the
// messages that receive dispatched (see Connection.inboundMessages).
type handlingNotification struct {
	conn    *Connection
	seq     uint64
	arrival uint64
}

type handlingNotificationKey struct{}

// handlingRequest is the ctx value that receive gives each handler of a
// request from the peer. arrival is the request's place among the messages
// that receive dispatched (see Connection.inboundMessages).
type handlingRequest struct {
	conn    *Connection
	arrival uint64
}

type handlingRequestKey struct{}

// notificationSeq returns the sequence number of the notification from c
// whose handler runs with ctx.
func (c *Connection) notificationSeq(ctx context.Context) (uint64, bool) {
	h, ok := ctx.Value(handlingNotificationKey{}).(handlingNotification)
	if !ok || h.conn != c {
		return 0, false
	}
	return h.seq, true
}

// messageArrival returns the arrival number of the request or notification
// from c whose handler runs with ctx. A message with a greater number arrived
// after it.
func (c *Connection) messageArrival(ctx context.Context) (uint64, bool) {
	if h, ok := ctx.Value(handlingRequestKey{}).(handlingRequest); ok && h.conn == c {
		return h.arrival, true
	}
	if h, ok := ctx.Value(handlingNotificationKey{}).(handlingNotification); ok && h.conn == c {
		return h.arrival, true
	}
	return 0, false
}

type responseEnvelope struct {
	receipt               *Receipt
	msg                   anyMessage
	notificationWatermark uint64
}

type pendingResponse struct {
	capture bool
	ch      chan responseEnvelope
}

type cancelRequestParams struct {
	RequestID json.RawMessage `json:"requestId"`
}

type MethodHandler func(ctx context.Context, method string, params json.RawMessage) (any, *RequestError)

// Connection is a simple JSON-RPC 2.0 connection over line-delimited JSON.
type Connection struct {
	inboundMethods         map[string]struct{}
	selectInbound          func(method, sessionID string) bool
	omitPlainNotifications bool
	w                      io.Writer
	r                      io.Reader
	handler                MethodHandler

	mu                   sync.Mutex
	writeMu              sync.Mutex
	nextID               atomic.Uint64
	pending              map[string]*pendingResponse
	inflight             map[string]context.CancelCauseFunc
	inboundMessages      uint64              // requests and queued notifications that receive dispatched; only receive touches it
	inflightArrivals     map[uint64]struct{} // arrival numbers of the requests in inflight
	pendingCancelRequest []string
	cancelRequestSignal  chan struct{}

	// ctx/cancel govern connection lifetime and are used for Done() and for canceling
	// callers waiting on responses when the peer disconnects.
	ctx    context.Context
	cancel context.CancelCauseFunc

	// inboundCtx/inboundCancel are used when invoking the inbound MethodHandler.
	// This ctx is intentionally kept alive long enough to process notifications
	// that were successfully received and queued just before a peer disconnect.
	// Otherwise, handlers that respect context cancellation may drop end-of-connection
	// messages that we already read off the wire.
	inboundCtx    context.Context
	inboundCancel context.CancelCauseFunc

	// logger is atomic because SetLogger may be called after NewConnection has
	// already spawned the receive/processNotifications goroutines that read it
	// via loggerOrDefault.
	logger atomic.Pointer[slog.Logger]

	notifyMu sync.Mutex
	// notifyCond coordinates response-scoped waits for sequential notification processing.
	notifyCond *sync.Cond
	// invariant: completedNotificationSeq <= lastEnqueuedNotificationSeq.
	lastEnqueuedNotificationSeq uint64
	completedNotificationSeq    uint64
	// peerWaits counts, per notification sequence number, the requests that
	// were made with the ctx of that notification's running handler and still
	// wait for the peer's response.
	peerWaits map[uint64]int

	// notificationQueue serializes notification processing to maintain order.
	// It is bounded to keep memory usage predictable.
	notificationQueue chan queuedNotification
}

func NewConnection(handler MethodHandler, peerInput io.Writer, peerOutput io.Reader) *Connection {
	return NewConnectionWithOptions(handler, peerInput, peerOutput, Options{})
}

// NewConnectionWithOptions installs optional receipt routing and the diagnostic
// logger before starting the single receive loop.
func NewConnectionWithOptions(handler MethodHandler, peerInput io.Writer, peerOutput io.Reader, opts Options) *Connection {
	ctx, cancel := context.WithCancelCause(context.Background())
	inboundCtx, inboundCancel := context.WithCancelCause(context.Background())
	c := &Connection{
		w:                   peerInput,
		r:                   peerOutput,
		handler:             handler,
		pending:             make(map[string]*pendingResponse),
		inflight:            make(map[string]context.CancelCauseFunc),
		inflightArrivals:    make(map[uint64]struct{}),
		peerWaits:           make(map[uint64]int),
		cancelRequestSignal: make(chan struct{}, 1),
		ctx:                 ctx,
		cancel:              cancel,
		inboundCtx:          inboundCtx,
		inboundCancel:       inboundCancel,
		notificationQueue:   make(chan queuedNotification, defaultMaxQueuedNotifications),
	}
	if opts.SelectInbound != nil && len(opts.InboundMethods) > 0 {
		c.inboundMethods = make(map[string]struct{}, len(opts.InboundMethods))
		for _, m := range opts.InboundMethods {
			c.inboundMethods[m] = struct{}{}
		}
		c.selectInbound = opts.SelectInbound
		c.omitPlainNotifications = opts.OmitPlainNotifications
	}
	c.SetLogger(opts.Logger)
	c.notifyCond = sync.NewCond(&c.notifyMu)
	go func() {
		<-c.ctx.Done()
		c.notifyMu.Lock()
		c.notifyCond.Broadcast()
		c.notifyMu.Unlock()
	}()
	go c.sendCancelRequests()
	go c.receive()
	go c.processNotifications()
	return c
}

// SetLogger installs a logger used for internal connection diagnostics.
// If unset, logs are written via the default logger.
func (c *Connection) SetLogger(l *slog.Logger) { c.logger.Store(l) }

func (c *Connection) loggerOrDefault() *slog.Logger {
	if l := c.logger.Load(); l != nil {
		return l
	}
	return slog.Default()
}

const (
	maxCanonicalJSONRPCIDKeyLen   = 4096
	maxCanonicalJSONRPCIDAbsExp10 = 4096
	maxPendingCancelRequests      = 1024
)

var (
	errInvalidJSONRPCNumericID  = errors.New("invalid json-rpc numeric id")
	errJSONRPCNumericIDTooLarge = errors.New("json-rpc numeric id too large")
)

func canonicalJSONRPCIDKey(raw json.RawMessage) (string, error) {
	trimmed := bytes.TrimSpace(raw)
	if len(trimmed) == 0 {
		return "", errors.New("empty json-rpc id")
	}

	dec := json.NewDecoder(bytes.NewReader(trimmed))
	dec.UseNumber()

	var id any
	if err := dec.Decode(&id); err != nil {
		return "", err
	}

	// Ensure the id contains a single JSON value.
	var trailing any
	if err := dec.Decode(&trailing); err == nil {
		return "", errors.New("invalid json-rpc id: trailing data")
	} else if !errors.Is(err, io.EOF) {
		return "", err
	}

	switch v := id.(type) {
	case nil:
		return "null", nil
	case string:
		canon, err := json.Marshal(v)
		if err != nil {
			return "", err
		}
		return string(canon), nil
	case json.Number:
		return canonicalJSONRPCNumericIDKey(v)
	default:
		return "", errors.New("json-rpc id must be string, number, or null")
	}
}

func canonicalJSONRPCNumericIDKey(v json.Number) (string, error) {
	raw := strings.TrimSpace(v.String())
	if raw == "" {
		return "", errInvalidJSONRPCNumericID
	}

	negative, digits, exp10, err := parseJSONRPCNumericID(raw)
	if err != nil {
		return "", err
	}

	return formatCanonicalJSONRPCNumericID(negative, digits, exp10)
}

func parseJSONRPCNumericID(raw string) (negative bool, digits string, exp10 int, err error) {
	i := 0
	if raw[i] == '-' {
		negative = true
		i++
		if i >= len(raw) {
			return false, "", 0, errInvalidJSONRPCNumericID
		}
	}

	intStart := i
	switch {
	case raw[i] == '0':
		i++
		if i < len(raw) && isASCIIDigit(raw[i]) {
			return false, "", 0, errInvalidJSONRPCNumericID
		}
	case raw[i] >= '1' && raw[i] <= '9':
		for i < len(raw) && isASCIIDigit(raw[i]) {
			i++
		}
	default:
		return false, "", 0, errInvalidJSONRPCNumericID
	}
	intDigits := raw[intStart:i]

	fracDigits := ""
	if i < len(raw) && raw[i] == '.' {
		i++
		fracStart := i
		for i < len(raw) && isASCIIDigit(raw[i]) {
			i++
		}
		if fracStart == i {
			return false, "", 0, errInvalidJSONRPCNumericID
		}
		fracDigits = raw[fracStart:i]
	}

	exponent := 0
	if i < len(raw) && (raw[i] == 'e' || raw[i] == 'E') {
		i++
		if i >= len(raw) {
			return false, "", 0, errInvalidJSONRPCNumericID
		}

		exponentSign := 1
		if raw[i] == '+' || raw[i] == '-' {
			if raw[i] == '-' {
				exponentSign = -1
			}
			i++
			if i >= len(raw) {
				return false, "", 0, errInvalidJSONRPCNumericID
			}
		}

		exponentStart := i
		for i < len(raw) && isASCIIDigit(raw[i]) {
			i++
		}
		if exponentStart == i {
			return false, "", 0, errInvalidJSONRPCNumericID
		}

		exponentMagnitude, parseErr := parseBoundedInt(raw[exponentStart:i], maxCanonicalJSONRPCIDAbsExp10)
		if parseErr != nil {
			return false, "", 0, parseErr
		}
		exponent = exponentSign * exponentMagnitude
	}

	if i != len(raw) {
		return false, "", 0, errInvalidJSONRPCNumericID
	}

	digits = strings.TrimLeft(intDigits+fracDigits, "0")
	if digits == "" {
		return false, "", 0, nil
	}
	if len(digits) > maxCanonicalJSONRPCIDKeyLen {
		return false, "", 0, errJSONRPCNumericIDTooLarge
	}

	exp10 = exponent - len(fracDigits)
	return negative, digits, exp10, nil
}

func parseBoundedInt(raw string, max int) (int, error) {
	if raw == "" {
		return 0, errInvalidJSONRPCNumericID
	}

	value := 0
	for i := 0; i < len(raw); i++ {
		if !isASCIIDigit(raw[i]) {
			return 0, errInvalidJSONRPCNumericID
		}
		digit := int(raw[i] - '0')
		if value > (max-digit)/10 {
			return 0, errJSONRPCNumericIDTooLarge
		}
		value = value*10 + digit
	}
	return value, nil
}

func isASCIIDigit(ch byte) bool {
	return ch >= '0' && ch <= '9'
}

func formatCanonicalJSONRPCNumericID(negative bool, digits string, exp10 int) (string, error) {
	for len(digits) > 0 && digits[len(digits)-1] == '0' {
		digits = digits[:len(digits)-1]
		exp10++
	}

	if digits == "" {
		return "0", nil
	}

	sign := ""
	if negative {
		sign = "-"
	}

	if exp10 >= 0 {
		if exp10 > maxCanonicalJSONRPCIDKeyLen-len(digits) {
			return "", errJSONRPCNumericIDTooLarge
		}
		result := digits + strings.Repeat("0", exp10)
		if sign != "" {
			result = sign + result
		}
		if len(result) > maxCanonicalJSONRPCIDKeyLen+len(sign) {
			return "", errJSONRPCNumericIDTooLarge
		}
		return result, nil
	}

	scale := -exp10
	if scale > maxCanonicalJSONRPCIDKeyLen {
		return "", errJSONRPCNumericIDTooLarge
	}

	if len(digits) > scale {
		intPart := digits[:len(digits)-scale]
		fracPart := digits[len(digits)-scale:]
		if len(intPart)+1+len(fracPart) > maxCanonicalJSONRPCIDKeyLen {
			return "", errJSONRPCNumericIDTooLarge
		}
		result := intPart + "." + fracPart
		if sign != "" {
			result = sign + result
		}
		return result, nil
	}

	leadingZeros := scale - len(digits)
	if leadingZeros > maxCanonicalJSONRPCIDKeyLen-len(digits)-2 {
		return "", errJSONRPCNumericIDTooLarge
	}
	result := "0." + strings.Repeat("0", leadingZeros) + digits
	if sign != "" {
		result = sign + result
	}
	return result, nil
}

func (c *Connection) receive() {
	const (
		initialBufSize = 1024 * 1024
		maxBufSize     = 10 * 1024 * 1024
	)

	scanner := bufio.NewScanner(c.r)
	buf := make([]byte, 0, initialBufSize)
	scanner.Buffer(buf, maxBufSize)

	for scanner.Scan() {
		line := scanner.Bytes()
		if len(bytes.TrimSpace(line)) == 0 {
			continue
		}

		var msg anyMessage
		if err := json.Unmarshal(line, &msg); err != nil {
			c.loggerOrDefault().Error("failed to parse incoming message")
			continue
		}

		// Handle $/cancel_request notifications synchronously so cancellations take effect
		// immediately and do not participate in notification ordering.
		if msg.ID == nil && msg.Method == "$/cancel_request" {
			c.handleCancelRequest(&msg)
			continue
		}

		switch {
		case msg.ID != nil && msg.Method == "":
			c.handleResponse(&msg, line)
		case msg.Method != "":
			var valid bool
			msg.inbound, valid = c.selectFrame(&msg, line)
			if !valid {
				c.loggerOrDefault().Error("ignored ambiguously routed inbound message")
				// Answer only when the peer supplied one unambiguous request ID.
				// The receive loop must not block on a peer that is still writing.
				if len(msg.ID) > 0 && hasSingleID(line) {
					go c.sendInboundRequestError(&msg, &RequestError{Code: -32600, Message: "Invalid request"})
				}
				continue
			}
			if msg.ID != nil {
				// Requests observe the notification queue as it stood when they arrived.
				// Notifications already accepted onto the queue must finish before the
				// handler starts, while later notifications must not delay the request.
				// The handler also starts while the running notification handler waits
				// for the peer, because the peer can need this answer first.
				c.notifyMu.Lock()
				watermark := c.lastEnqueuedNotificationSeq
				c.notifyMu.Unlock()

				idKey, err := canonicalJSONRPCIDKey(msg.ID)
				if err != nil {
					c.loggerOrDefault().Error("failed to canonicalize inbound request id")
					idKey = string(msg.ID)
				}
				reqCtx, cancel := context.WithCancelCause(c.ctx)
				c.inboundMessages++
				arrival := c.inboundMessages
				reqCtx = context.WithValue(reqCtx, handlingRequestKey{}, handlingRequest{conn: c, arrival: arrival})

				c.mu.Lock()
				c.inflight[idKey] = cancel
				c.inflightArrivals[arrival] = struct{}{}
				c.mu.Unlock()

				m := msg
				go func(m *anyMessage, idKey string, reqCtx context.Context, cancel context.CancelCauseFunc, watermark uint64) {
					defer func() {
						c.mu.Lock()
						delete(c.inflight, idKey)
						delete(c.inflightArrivals, arrival)
						c.mu.Unlock()

						cancel(nil)
					}()
					if err := c.waitInboundBarrier(reqCtx, watermark); err != nil {
						select {
						case <-c.Done():
							// Preserve the existing disconnect contract: start accepted request
							// handlers with a canceled context so they can run cleanup even when
							// an earlier notification is still draining. The peer can no longer
							// observe notification/request ordering after disconnect.
							c.handleInbound(reqCtx, m)
							return
						default:
						}
						c.sendInboundRequestError(m, toReqErr(err))
						return
					}
					c.handleInbound(reqCtx, m)
				}(&m, idKey, reqCtx, cancel, watermark)
				continue
			}

			// Queue the notification for sequential processing. The sequence number marks
			// the response-scoped barrier boundary for requests that observe later responses.
			m := msg
			c.inboundMessages++
			c.notifyMu.Lock()
			c.lastEnqueuedNotificationSeq++
			seq := c.lastEnqueuedNotificationSeq
			select {
			case c.notificationQueue <- queuedNotification{seq: seq, arrival: c.inboundMessages, msg: &m}:
				c.notifyMu.Unlock()
			default:
				if c.lastEnqueuedNotificationSeq != seq {
					c.notifyMu.Unlock()
					panic("notification sequence advanced while receive goroutine was queueing")
				}
				c.lastEnqueuedNotificationSeq--
				// invariant: completedNotificationSeq never exceeds the highest accepted enqueue.
				if c.completedNotificationSeq > c.lastEnqueuedNotificationSeq {
					c.notifyMu.Unlock()
					panic("completed notification sequence exceeded enqueued notification sequence")
				}
				c.notifyMu.Unlock()
				c.loggerOrDefault().Error("failed to queue notification; closing connection", "err", errNotificationQueueOverflow, "capacity", cap(c.notificationQueue), "queued", len(c.notificationQueue))
				c.shutdownReceive(errNotificationQueueOverflow)
				return
			}
		default:
			c.loggerOrDefault().Error("received message with neither id nor method")
		}
	}

	cause := errors.New("peer connection closed")
	if err := scanner.Err(); err != nil {
		cause = err
	}
	c.shutdownReceive(cause)
}

func (c *Connection) shutdownReceive(cause error) {
	if cause == nil {
		cause = errors.New("connection closed")
	}

	// First, signal disconnect to callers waiting on responses.
	c.cancel(cause)

	// Then close the notification queue so already-received messages can drain.
	// IMPORTANT: Do not block this receive goroutine waiting for the drain to complete;
	// notification handlers may legitimately block until their context is canceled.
	close(c.notificationQueue)

	c.notifyMu.Lock()
	finalEnqueuedSeq := c.lastEnqueuedNotificationSeq
	if c.completedNotificationSeq > finalEnqueuedSeq {
		c.notifyMu.Unlock()
		panic("completed notification sequence exceeded final enqueued sequence during shutdown")
	}
	c.notifyMu.Unlock()

	// Cancel inboundCtx after notifications finish, but ensure we don't leak forever if a
	// handler blocks waiting for cancellation.
	go func(finalEnqueuedSeq uint64) {
		c.waitForNotificationDrain(finalEnqueuedSeq, notificationQueueDrainTimeout)
		c.inboundCancel(cause)
	}(finalEnqueuedSeq)

	c.loggerOrDefault().Info("connection closed")
}

// processNotifications processes notifications sequentially to maintain order.
// It terminates when notificationQueue is closed (e.g. on disconnect in receive()).
func (c *Connection) processNotifications() {
	for queued := range c.notificationQueue {
		handlerCtx := context.WithValue(c.inboundCtx, handlingNotificationKey{}, handlingNotification{conn: c, seq: queued.seq, arrival: queued.arrival})
		c.handleInbound(handlerCtx, queued.msg)

		c.notifyMu.Lock()
		expectedSeq := c.completedNotificationSeq + 1
		if queued.seq != expectedSeq {
			c.notifyMu.Unlock()
			panic("notification sequence completed out of order")
		}
		c.completedNotificationSeq = queued.seq
		if c.completedNotificationSeq > c.lastEnqueuedNotificationSeq {
			c.notifyMu.Unlock()
			panic("completed notification sequence exceeded enqueued notification sequence")
		}
		c.notifyCond.Broadcast()
		c.notifyMu.Unlock()
	}
}

func (c *Connection) handleResponse(msg *anyMessage, line []byte) {
	idStr, err := canonicalJSONRPCIDKey(msg.ID)
	if err != nil {
		c.loggerOrDefault().Error("failed to canonicalize response id")
		idStr = string(msg.ID)
	}

	c.mu.Lock()
	pr := c.pending[idStr]
	c.mu.Unlock()
	if pr == nil {
		return
	}
	var receipt *Receipt
	if pr.capture {
		if (msg.Error == nil && len(msg.Result) == 0) || !unambiguousReply(line) {
			c.loggerOrDefault().Error("ignored ambiguous response")
			return
		}
		receipt = copyReceipt(msg, line)
	}
	c.notifyMu.Lock()
	watermark := c.lastEnqueuedNotificationSeq
	if c.completedNotificationSeq > watermark {
		c.notifyMu.Unlock()
		panic("completed notification sequence exceeded response watermark")
	}
	c.notifyMu.Unlock()
	// The buffered send and pending removal commit under the same lock that
	// cancellation uses to abandon this call. A completed match wins over a
	// simultaneous shutdown without publishing an abandoned frame to a caller.
	c.mu.Lock()
	if c.pending[idStr] == pr {
		pr.ch <- responseEnvelope{msg: *msg, notificationWatermark: watermark, receipt: receipt}
		delete(c.pending, idStr)
	}
	c.mu.Unlock()
}

func (c *Connection) handleCancelRequest(msg *anyMessage) {
	var p cancelRequestParams
	if err := json.Unmarshal(msg.Params, &p); err != nil {
		c.loggerOrDefault().Error("failed to parse $/cancel_request params")
		return
	}
	if len(bytes.TrimSpace(p.RequestID)) == 0 {
		c.loggerOrDefault().Error("received $/cancel_request without requestId")
		return
	}

	idKey, err := canonicalJSONRPCIDKey(p.RequestID)
	if err != nil {
		c.loggerOrDefault().Error("failed to canonicalize $/cancel_request requestId")
		idKey = string(p.RequestID)
	}

	c.mu.Lock()
	cancel := c.inflight[idKey]
	c.mu.Unlock()
	if cancel == nil {
		return
	}

	cancel(context.Canceled)
}

func (c *Connection) handleInbound(ctx context.Context, req *anyMessage) {
	res := anyMessage{JSONRPC: "2.0"}

	// copy ID if present
	if req.ID != nil {
		res.ID = req.ID
	}
	if c.handler == nil {
		if req.ID != nil {
			res.Error = NewMethodNotFound(req.Method)
			_ = c.sendMessage(res)
		}
		return
	}

	if req.inbound != nil {
		ctx = context.WithValue(ctx, receiptContextKey{}, req.inbound)
	}
	result, err := c.handler(ctx, req.Method, req.Params)
	if req.ID == nil {
		// Notification: no response is sent; log handler errors to surface decode failures.
		if err != nil {
			if err.Code == -32601 {
				// Per ACP, unknown extension notifications should be ignored.
				if strings.HasPrefix(req.Method, "_") {
					return
				}
				// A notification needs no answer, so one that this side does
				// not handle, such as an optional method that the Client or
				// Agent does not implement, is not a failure.
				c.loggerOrDefault().Debug("ignored unhandled notification")
				return
			}
			c.loggerOrDefault().Error("failed to handle notification")
		}
		return
	}
	if err != nil {
		res.Error = c.encodableError(req.Method, err)
	} else {
		// marshal result
		b, mErr := json.Marshal(result)
		if mErr != nil {
			res.Error = NewInternalError(map[string]any{"error": mErr.Error()})
		} else {
			res.Result = b
		}
	}
	_ = c.sendMessage(res)
}

func (c *Connection) sendInboundRequestError(req *anyMessage, err *RequestError) {
	if req.ID == nil {
		return
	}
	_ = c.sendMessage(anyMessage{
		JSONRPC: "2.0",
		ID:      req.ID,
		Error:   err,
	})
}

func (c *Connection) sendMessage(msg anyMessage) error {
	msg.JSONRPC = "2.0"
	b, err := json.Marshal(msg)
	if err != nil {
		return err
	}
	b = append(b, '\n')

	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	n, err := c.w.Write(b)
	if err == nil && n != len(b) {
		return io.ErrShortWrite
	}
	return err
}

// SendRequest sends a JSON-RPC request and returns a typed result.
// For methods that do not return a result, use SendRequestNoResult instead.
//
// SendRequest returns after the handlers of all notifications that arrived
// before the response have returned. A notification handler that makes a
// request on the same connection must pass its own ctx, or a ctx derived from
// it. While the handler runs, such a request waits only for the notifications
// before the handler's own. With any other ctx, such as context.Background(),
// the request waits for the handler that made it, so it returns only when ctx
// ends or the peer disconnects. The shorter wait applies to every goroutine that
// uses the handler's ctx while the handler runs: a goroutine that the handler
// starts and that needs the full wait must get a ctx that does not derive from
// the handler's ctx.
func SendRequest[T any](c *Connection, ctx context.Context, method string, params any) (T, error) {
	result, _, err := sendRequest[T](c, ctx, method, params, false)
	return result, err
}

// SendRequestWithReceipt returns the original matched response after the same
// notification barrier as SendRequest. Local failures before delivery have no receipt.
func SendRequestWithReceipt[T any](c *Connection, ctx context.Context, method string, params any) (T, *Receipt, error) {
	return sendRequest[T](c, ctx, method, params, true)
}

func sendRequest[T any](c *Connection, ctx context.Context, method string, params any, capture bool) (T, *Receipt, error) {
	var result T

	msg, idKey, err := c.prepareRequest(method, params)
	if err != nil {
		return result, nil, err
	}

	pr := &pendingResponse{capture: capture, ch: make(chan responseEnvelope, 1)}
	c.mu.Lock()
	c.pending[idKey] = pr
	c.mu.Unlock()

	if err := c.sendMessage(msg); err != nil {
		c.cleanupPending(idKey)
		return result, nil, NewInternalError(map[string]any{"error": err.Error()})
	}

	donePeerWait := c.startPeerWait(ctx)
	resp, err := c.waitForResponse(ctx, pr, idKey)
	donePeerWait()
	if err != nil {
		return result, nil, err
	}
	if err := c.waitNotificationsUpTo(ctx, resp.notificationWatermark); err != nil {
		if resp.receipt != nil {
			return result, resp.receipt, &DeliveryError{Err: err}
		}
		return result, nil, err
	}

	if resp.msg.Error != nil {
		return result, resp.receipt, resp.msg.Error
	}

	if len(resp.msg.Result) > 0 {
		if err := json.Unmarshal(resp.msg.Result, &result); err != nil {
			local := NewInternalError(map[string]any{"error": err.Error()})
			if resp.receipt != nil {
				return result, resp.receipt, &DeliveryError{Err: local}
			}
			return result, nil, local
		}
	}
	return result, resp.receipt, nil
}

func (c *Connection) prepareRequest(method string, params any) (anyMessage, string, error) {
	id := c.nextID.Add(1)
	idRaw, _ := json.Marshal(id)

	msg := anyMessage{
		JSONRPC: "2.0",
		ID:      idRaw,
		Method:  method,
	}

	if params != nil {
		b, err := json.Marshal(params)
		if err != nil {
			return msg, "", NewInvalidParams(map[string]any{"error": err.Error()})
		}
		msg.Params = b
	}

	return msg, string(idRaw), nil
}

func (c *Connection) sendCancelRequests() {
	for {
		select {
		case <-c.Done():
			return
		case <-c.cancelRequestSignal:
			for {
				c.mu.Lock()
				if len(c.pendingCancelRequest) == 0 {
					c.mu.Unlock()
					break
				}
				idKey := c.pendingCancelRequest[0]
				c.pendingCancelRequest = c.pendingCancelRequest[1:]
				c.mu.Unlock()

				requestID := json.RawMessage(append([]byte(nil), idKey...))
				if err := c.SendNotification(context.Background(), "$/cancel_request", cancelRequestParams{RequestID: requestID}); err != nil {
					c.loggerOrDefault().Debug("failed to send $/cancel_request")
				}
			}
		}
	}
}

func (c *Connection) sendCancelRequest(idKey string) {
	if strings.TrimSpace(idKey) == "" {
		return
	}

	select {
	case <-c.Done():
		return
	default:
	}

	queueFull := false
	c.mu.Lock()
	if len(c.pendingCancelRequest) >= maxPendingCancelRequests {
		queueFull = true
	} else {
		c.pendingCancelRequest = append(c.pendingCancelRequest, idKey)
	}
	c.mu.Unlock()

	if queueFull {
		c.loggerOrDefault().Debug("dropping $/cancel_request due to full queue", "queue_len", maxPendingCancelRequests)
		return
	}

	select {
	case c.cancelRequestSignal <- struct{}{}:
	default:
	}
}

// takeOrAbandon resolves cancellation against response delivery atomically.
func (c *Connection) takeOrAbandon(pr *pendingResponse, idKey string) (responseEnvelope, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	select {
	case resp := <-pr.ch:
		return resp, true
	default:
	}
	if c.pending[idKey] == pr {
		delete(c.pending, idKey)
	}
	return responseEnvelope{}, false
}

func (c *Connection) waitForResponse(ctx context.Context, pr *pendingResponse, idKey string) (responseEnvelope, error) {
	peerDisconnectedErr := NewInternalError(map[string]any{"error": "peer disconnected before response"})
	select {
	case resp := <-pr.ch:
		return resp, nil
	case <-ctx.Done():
		if resp, matched := c.takeOrAbandon(pr, idKey); matched {
			return resp, nil
		}
		select {
		case <-c.Done():
			return responseEnvelope{}, peerDisconnectedErr
		default:
		}
		c.sendCancelRequest(idKey)
		cause := context.Cause(ctx)
		if cause == nil {
			cause = ctx.Err()
		}
		if cause != nil {
			return responseEnvelope{}, toReqErr(cause)
		}
		return responseEnvelope{}, NewInternalError(map[string]any{"error": "request context ended without cause"})
	case <-c.Done():
		if resp, matched := c.takeOrAbandon(pr, idKey); matched {
			return resp, nil
		}
		return responseEnvelope{}, peerDisconnectedErr
	}
}

func (c *Connection) waitNotificationsUpTo(ctx context.Context, target uint64) error {
	return c.waitNotifications(ctx, target, false)
}

// waitNotifications waits until the handlers of the notifications up to
// target have returned. With stopAtPeerWait, it also returns while the running
// notification handler waits for a response from the peer: the request from
// the peer that waits here can be the one that the peer must get an answer to
// before it answers the handler.
func (c *Connection) waitNotifications(ctx context.Context, target uint64, stopAtPeerWait bool) error {
	if target == 0 {
		return nil
	}

	peerDisconnectedErr := NewInternalError(map[string]any{"error": "peer disconnected while waiting for pre-response notifications"})
	stopWake := make(chan struct{})
	defer close(stopWake)

	c.notifyMu.Lock()
	defer c.notifyMu.Unlock()
	if target > c.lastEnqueuedNotificationSeq {
		panic("response watermark exceeded last enqueued notification sequence")
	}
	// While the handler of notification h.seq runs, it can be the caller, on the
	// goroutine that completes h.seq. A wait for h.seq or a later notification
	// would then never end. After h.seq completes, its ctx gets the full wait.
	if h, ok := ctx.Value(handlingNotificationKey{}).(handlingNotification); ok && h.conn == c && c.completedNotificationSeq < h.seq {
		target = min(target, h.seq-1)
	}

	go func() {
		select {
		case <-ctx.Done():
		case <-stopWake:
			return
		}
		c.notifyMu.Lock()
		c.notifyCond.Broadcast()
		c.notifyMu.Unlock()
	}()

	for c.completedNotificationSeq < target && !(stopAtPeerWait && c.peerWaits[c.completedNotificationSeq+1] > 0) {
		if c.completedNotificationSeq > c.lastEnqueuedNotificationSeq {
			panic("completed notification sequence exceeded enqueued notification sequence while waiting")
		}

		select {
		case <-c.Done():
			return peerDisconnectedErr
		default:
		}
		select {
		case <-ctx.Done():
			select {
			case <-c.Done():
				return peerDisconnectedErr
			default:
			}
			cause := context.Cause(ctx)
			if cause == nil {
				cause = ctx.Err()
			}
			if cause != nil {
				return toReqErr(cause)
			}
			return NewInternalError(map[string]any{"error": "request context ended without cause while waiting for notifications"})
		default:
		}

		c.notifyCond.Wait()
	}
	return nil
}

// waitInboundBarrier waits until the handler of a request from the peer with
// watermark can start. A $/cancel_request or a disconnect can end ctx just as
// the barrier clears. It then returns the cancel error, as if ctx had ended the
// wait.
func (c *Connection) waitInboundBarrier(ctx context.Context, watermark uint64) error {
	if err := c.waitNotifications(ctx, watermark, true); err != nil {
		return err
	}
	if cause := context.Cause(ctx); cause != nil {
		return toReqErr(cause)
	}
	return nil
}

// startPeerWait records that a request made with ctx waits for the peer's
// response, if ctx belongs to the running notification handler. The returned
// func ends the record.
func (c *Connection) startPeerWait(ctx context.Context) func() {
	seq, ok := c.notificationSeq(ctx)
	if !ok {
		return func() {}
	}
	c.notifyMu.Lock()
	defer c.notifyMu.Unlock()
	if c.completedNotificationSeq >= seq {
		// The handler has returned. Requests with its ctx get the full wait.
		return func() {}
	}
	c.peerWaits[seq]++
	c.notifyCond.Broadcast()
	return func() {
		c.notifyMu.Lock()
		defer c.notifyMu.Unlock()
		if c.peerWaits[seq] <= 0 {
			panic("peer wait count went below zero")
		}
		if c.peerWaits[seq]--; c.peerWaits[seq] == 0 {
			delete(c.peerWaits, seq)
		}
	}
}

// oldestInflightArrival returns the smallest arrival number of the requests
// from the peer whose handlers have not returned. ok is false when there are
// none.
func (c *Connection) oldestInflightArrival() (oldest uint64, ok bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for a := range c.inflightArrivals {
		if !ok || a < oldest {
			oldest, ok = a, true
		}
	}
	return oldest, ok
}

func (c *Connection) waitForNotificationDrain(target uint64, timeout time.Duration) {
	if target == 0 {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	stopWake := make(chan struct{})
	defer close(stopWake)

	c.notifyMu.Lock()
	defer c.notifyMu.Unlock()
	if target > c.lastEnqueuedNotificationSeq {
		panic("drain target exceeded last enqueued notification sequence")
	}

	go func() {
		select {
		case <-ctx.Done():
		case <-stopWake:
			return
		}
		c.notifyMu.Lock()
		c.notifyCond.Broadcast()
		c.notifyMu.Unlock()
	}()

	for c.completedNotificationSeq < target {
		if c.completedNotificationSeq > c.lastEnqueuedNotificationSeq {
			panic("completed notification sequence exceeded enqueued notification sequence during drain")
		}
		if ctx.Err() != nil {
			return
		}
		c.notifyCond.Wait()
	}
}

func (c *Connection) cleanupPending(idKey string) {
	c.mu.Lock()
	delete(c.pending, idKey)
	c.mu.Unlock()
}

// SendRequestNoResult sends a JSON-RPC request that returns no result payload.
// It waits for notification handlers as SendRequest does.
func (c *Connection) SendRequestNoResult(ctx context.Context, method string, params any) error {
	msg, idKey, err := c.prepareRequest(method, params)
	if err != nil {
		return err
	}

	pr := &pendingResponse{ch: make(chan responseEnvelope, 1)}
	c.mu.Lock()
	c.pending[idKey] = pr
	c.mu.Unlock()

	if err := c.sendMessage(msg); err != nil {
		c.cleanupPending(idKey)
		return NewInternalError(map[string]any{"error": err.Error()})
	}

	donePeerWait := c.startPeerWait(ctx)
	resp, err := c.waitForResponse(ctx, pr, idKey)
	donePeerWait()
	if err != nil {
		return err
	}
	if err := c.waitNotificationsUpTo(ctx, resp.notificationWatermark); err != nil {
		return err
	}

	if resp.msg.Error != nil {
		return resp.msg.Error
	}
	return nil
}

func (c *Connection) SendNotification(ctx context.Context, method string, params any) error {
	select {
	case <-ctx.Done():
		return NewInternalError(map[string]any{"error": ctx.Err().Error()})
	default:
	}

	msg, err := c.prepareNotification(method, params)
	if err != nil {
		return err
	}

	if err := c.sendMessage(msg); err != nil {
		return NewInternalError(map[string]any{"error": err.Error()})
	}
	return nil
}

func (c *Connection) prepareNotification(method string, params any) (anyMessage, error) {
	msg := anyMessage{
		JSONRPC: "2.0",
		Method:  method,
	}

	if params != nil {
		b, err := json.Marshal(params)
		if err != nil {
			return msg, NewInvalidParams(map[string]any{"error": err.Error()})
		}
		msg.Params = b
	}

	return msg, nil
}

// Done returns a channel that is closed when the underlying reader loop exits
// (typically when the peer disconnects or the input stream is closed).
func (c *Connection) Done() <-chan struct{} {
	return c.ctx.Done()
}

// encodableError returns err, the error of the handler of method, when it
// encodes as JSON. Otherwise, as when its Data is not valid JSON, it logs the
// encode error and returns an internal error, so that the peer gets a response
// instead of waiting for one that never comes.
func (c *Connection) encodableError(method string, err *RequestError) *RequestError {
	if _, mErr := json.Marshal(err); mErr != nil {
		c.loggerOrDefault().Error("failed to encode the error of a request handler")
		return NewInternalError(map[string]any{"error": mErr.Error()})
	}
	return err
}
